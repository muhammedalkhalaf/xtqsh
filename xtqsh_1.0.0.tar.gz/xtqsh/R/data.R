#' Sample Panel Data for Slope Homogeneity Testing
#'
#' A simulated panel dataset designed to demonstrate the \code{\link{xtqsh}}
#' function. The data is generated under slope homogeneity, meaning the
#' true slope coefficients are equal across all panels.
#'
#' @format A data frame with 2000 rows and 5 variables:
#' \describe{
#'   \item{id}{Panel (cross-section) identifier, integers 1 to 20}
#'   \item{time}{Time period identifier, integers 1 to 100}
#'   \item{y}{Dependent variable}
#'   \item{x1}{First independent variable}
#'   \item{x2}{Second independent variable}
#' }
#'
#' @details
#' The data is generated from the model:
#' \deqn{y_{it} = \alpha_i + \beta_1 x_{1,it} + \beta_2 x_{2,it} + \varepsilon_{it}}
#'
#' where \eqn{\alpha_i} are panel-specific fixed effects, \eqn{\beta_1 = 1.5}
#' and \eqn{\beta_2 = -0.8} are common slope coefficients, and
#' \eqn{\varepsilon_{it}} are i.i.d. standard normal errors.
#'
#' The true slope coefficients are homogeneous across panels by construction,
#' so the null hypothesis of slope homogeneity should not be rejected.
#'
#' @examples
#' data(qsh_sample)
#' head(qsh_sample)
#'
#' # Test slope homogeneity
#' fit <- xtqsh(y ~ x1 + x2, data = qsh_sample, id = "id", time = "time",
#'              tau = c(0.25, 0.50, 0.75))
#' summary(fit)
#'
#' @source Simulated data for package demonstration.
#'
#' @seealso \code{\link{xtqsh}}
"qsh_sample"
